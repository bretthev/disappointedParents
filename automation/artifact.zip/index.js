"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Alexa = require('alexa-sdk');
var config_1 = require("./src/config");
var handlers_1 = require("./src/handlers");
function handler(event, context, callback) {
    console.log('event', event);
    console.log('context', context);
    var alexa = Alexa.handler(event, context);
    alexa.appId = config_1.ALEXA_SKILL_ID;
    alexa.registerHandlers(handlers_1.handlers);
    alexa.execute();
}
exports.handler = handler;
