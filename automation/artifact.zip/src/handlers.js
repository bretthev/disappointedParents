"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var launchresponse_1 = require("./alexaResponses/launchresponse");
var greeting_1 = require("./alexaResponses/greeting");
var disappointedResponses_1 = require("./alexaResponses/disappointedResponses");
var askIfProud_1 = require("./alexaResponses/askIfProud");
var compareToSiblings_1 = require("./alexaResponses/compareToSiblings");
var farewell_1 = require("./alexaResponses/farewell");
exports.handlers = {
    'LaunchRequest': function () {
        this.emit(':tell', grabRandomResponse(launchresponse_1.launchResponses));
    },
    'Greeting': function () {
        this.emit(':tell', grabRandomResponse(greeting_1.greetings));
    },
    'AskIfDisappointed': function () {
        this.emit(':tell', grabRandomResponse(disappointedResponses_1.disappointedResponses));
    },
    'AskIfProud': function () {
        this.emit(':tell', grabRandomResponse(askIfProud_1.askIfProudResponses));
    },
    'CompareToSiblings': function () {
        this.emit(':tell', grabRandomResponse(compareToSiblings_1.compareToSiblingsResponses));
    },
    'Farewell': function () {
        this.emit(':tell', grabRandomResponse(farewell_1.farewells));
    }
};
function grabRandomResponse(responses) {
    if (responses.length === 1) {
        return responses[0];
    }
    return responses[Math.floor(Math.random() * responses.length)];
}
