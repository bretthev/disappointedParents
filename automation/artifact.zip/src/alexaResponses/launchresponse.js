"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.launchResponses = [
    "You can ask this skill if your parents are proud of you. Spoiler alert: they are not.",
    "This skill will remind you that your parents think your siblings are more successful than you.",
    "This skill will let you know if your parents are proud of you, which they are definitely not."
];
