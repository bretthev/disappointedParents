"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.askIfProudResponses = [
    "No, we are not proud of you.",
    "Of course we aren't proud of you.",
    "Is that a serious questions? No. We're not proud.",
    "Ha. Haha. Hahahaha."
];
