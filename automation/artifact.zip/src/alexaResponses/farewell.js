"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.farewells = [
    "Deep, exasperated sigh. Maybe next time we talk you'll have done something that'll make us proud.",
    "Goodbye. We can't wait until Alexa allows you to choose a disappointed tone, because we will use it whenever we talk with you.",
    "Fine.",
    "Goodbye, our disappointing child."
];
