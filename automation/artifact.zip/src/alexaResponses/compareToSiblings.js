"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.compareToSiblingsResponses = [
    "You are definitely our least impressive child.",
    "Why can't you be more like our successful children?",
    "It's not that we love you less, it's just that you're a much bigger disappointment."
];
