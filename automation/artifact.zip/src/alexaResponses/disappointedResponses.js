"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.disappointedResponses = [
    "This is your parents. We are disappointed in everything you do.",
    "We are surprised that you still have to ask. Of course we're disappointed.",
    "We're too disappointed to talk to you right now, sorry.",
    "We are honestly kind of impressed by the number of ways you manage to disappoint us."
];
