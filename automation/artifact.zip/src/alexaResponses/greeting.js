"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.greetings = [
    "Hello, disappointing child.",
    "What now?",
    "Greetings from your disappointed parents.",
    "We are your parents and we are disappointed in you. Ask us anything."
];
