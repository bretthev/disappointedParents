"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ALEXA_SKILL_ID = process.env.ALEXA_SKILL_ID;
